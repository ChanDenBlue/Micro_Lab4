/*
 * scheduler.c
 *
 *  Created on: May 18, 2024
 *      Author: khanh
 */

#include "scheduler.h"
#include <stddef.h>

TaskNode* head = NULL;

void SCH_Init(void) {
	head = NULL;
}
void SCH_Add_Task(void (*pFunction)(void), uint32_t DELAY, uint32_t PERIOD) {
    TaskNode* newNode = malloc(sizeof(TaskNode));
    if (newNode == NULL) {
    //    return RETURN_ERROR; // not enough space
    	return ;
    }
    newNode->pTask = pFunction;
    newNode->Delay = DELAY;
    newNode->Period = PERIOD;
    newNode->RunMe = 0;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
    } else {
        TaskNode* current = head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
    }
    //return RETURN_NORMAL;
}
//	void SCH_Add_Task( void (*pFunction)(), uint32_t DELAY, uint32_t PERIOD) {
//		if(current_index_task < SCH_MAX_TASKS) {
//			SCH_tasks_G[current_index_task].pTask = pFunction;
//			SCH_tasks_G[current_index_task].Delay = DELAY;
//			SCH_tasks_G[current_index_task].Period = PERIOD;
//			SCH_tasks_G[current_index_task].RunMe = 0;
//
//			SCH_tasks_G[current_index_task].TaskID = current_index_task;
//
//			current_index_task ++;
//		}
//	}

//void SCH_Update(void) {
//	for(int i = 0; i < current_index_task; i++) {
//		if(SCH_tasks_G[i].Delay > 0){
//			SCH_tasks_G[i].Delay --;
//		} else{
//			SCH_tasks_G[i].Delay = SCH_tasks_G[i].Period;
//			SCH_tasks_G[i].RunMe += 1;
//		}
//	}
//}
//void SCH_Dispatch_Tasks(void) {
//	for(int i = 0; i < current_index_task; i++) {
//		if(SCH_tasks_G[i].RunMe > 0) {
//			SCH_tasks_G[i].RunMe --;
//			(*SCH_tasks_G[i].pTask)();
//		}
//	}
//}
//void SCH_Delete_Task(const uint8_t index){
//	if(SCH_tasks_G[index].pTask == 0){
//		return;
//	}
//	SCH_tasks_G[index].pTask 	= 0x0000;
//	SCH_tasks_G[index].Delay 	= 0;
//	SCH_tasks_G[index].Period 	= 0;
//	SCH_tasks_G[index].RunMe 	= 0;
//	current_index_task --;
//}
void SCH_Update(void) {
    TaskNode* current = head;
    while (current != NULL) {
        if (current->Delay == 0) {
            current->RunMe++;
            if (current->Period > 0) {
                current->Delay = current->Period;
            }
        } else {
            current->Delay--;
        }
        current = current->next;
    }
}

void SCH_Dispatch_Tasks(void) {
    TaskNode* current = head;
    while (current != NULL) {
        if (current->RunMe > 0) {
            current->pTask();
            current->RunMe--;
            if (current->Period == 0) {
                TaskNode* temp = current;
                current = current->next;
                SCH_Delete_Task(temp);
                continue;
            }
        }
        current = current->next;
    }
}
void SCH_Delete_Task(uint8_t taskIndex) {
    TaskNode* current = head;
    TaskNode* previous = NULL;
    uint8_t index = 0;

    while (current != NULL && index != taskIndex) {
        previous = current;
        current = current->next;
        index++;
    }

    if (current == NULL) {
        // if task does not exist
        return;
    }

    if (previous == NULL) {
        // if it is the first task
        head = current->next;
    } else {
        previous->next = current->next;
    }

    free(current);
}


