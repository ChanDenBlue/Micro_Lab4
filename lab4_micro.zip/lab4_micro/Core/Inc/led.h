/*
 * led.h
 *
 *  Created on: May 19, 2024
 *      Author: khanh
 */

#ifndef INC_LED_H_
#define INC_LED_H_

#include "main.h"


void ToggleLed_5(void);
void ToggleLed_1(void);
void ToggleLed_2(void);
void ToggleLed_3(void);
void ToggleLed_4(void);

#endif /* INC_LED_H_ */
